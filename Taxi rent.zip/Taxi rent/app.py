import streamlit as st
import torch
import torch.nn as nn
import numpy as np
import pandas as pd
from datetime import datetime

# --- 1. Define the Haversine Distance Function ---
# This function calculates the distance between two points given their latitudes and longitudes.
def haversine_distance(df, lat1, long1, lat2, long2):
    r = 6371  # Radius of Earth in kilometers
    
    # Convert latitudes and longitudes from degrees to radians
    phi1 = np.radians(df[lat1])
    phi2 = np.radians(df[lat2])
    delta_phi = np.radians(df[lat2] - df[lat1])
    delta_lambda = np.radians(df[long2] - df[long1])
    
    # Haversine formula
    a = np.sin(delta_phi / 2)**2 + np.cos(phi1) * np.cos(phi2) * np.sin(delta_lambda / 2)**2
    c = 2 * np.arctan2(np.sqrt(a), np.sqrt(1 - a))
    
    return r * c # Distance in kilometers

# --- 2. Define the Neural Network Architecture (TabularModel) ---
# This class defines the structure of the neural network, including embedding layers
# for categorical features and linear layers for the main network.
class TabularModel(nn.Module):
    def __init__(self, emb_szs, n_cont, out_sz, layers, p=0.5):
        super().__init__()
        
        # Create embedding layers for each categorical feature
        self.embeds = nn.ModuleList([nn.Embedding(ni, nf) for ni, nf in emb_szs])
        
        # Dropout layer for embeddings to prevent overfitting
        self.emb_drop = nn.Dropout(p)
        
        # Batch normalization for continuous features
        self.bn_cont = nn.BatchNorm1d(n_cont)
        
        # Build the main part of the neural network (dense layers)
        layerlist = []
        n_emb = sum((nf for ni, nf in emb_szs)) # Total size of all embeddings
        n_in = n_emb + n_cont # Total input features to the dense layers
        
        for i in layers: # Iterate through the specified layer sizes
            layerlist.append(nn.Linear(n_in, i)) # Add a linear layer
            layerlist.append(nn.ReLU(inplace=True)) # Add ReLU activation
            layerlist.append(nn.BatchNorm1d(i)) # Add batch normalization
            layerlist.append(nn.Dropout(p)) # Add dropout
            n_in = i # Update input size for the next layer
            
        layerlist.append(nn.Linear(layers[-1], out_sz)) # Final output layer
        self.layers = nn.Sequential(*layerlist) # Combine all layers into a sequential model

    def forward(self, x_cat, x_cont):
        # Process categorical inputs through their embedding layers
        embeddings = []
        for i, e in enumerate(self.embeds):
            embeddings.append(e(x_cat[:, i]))
            
        # Concatenate all embeddings
        x = torch.cat(embeddings, 1)
        x = self.emb_drop(x) # Apply dropout to embeddings
        
        # Process continuous inputs through batch normalization
        x_cont = self.bn_cont(x_cont)
        
        # Concatenate embeddings and continuous features
        x = torch.cat([x, x_cont], 1)
        
        # Pass through the main dense layers
        return self.layers(x)

# --- 3. Load the Trained Model ---
# Use Streamlit's cache_resource decorator to load the model only once
# when the app starts, improving performance.
@st.cache_resource
def load_trained_model():
    # Model parameters (must match training parameters)
    # emb_szs: List of tuples, where each tuple is (number_of_unique_categories, embedding_dimension)
    # Hour (0-23, 24 unique), AMorPM (0,1, 2 unique), Weekday (0-6, 7 unique)
    emb_szs = [(24, 12), (2, 1), (7, 4)] 
    n_cont = 6 # Number of continuous features
    out_sz = 1 # Output size (fare amount)
    layers = [200, 100] # Hidden layer sizes
    p = 0.4 # Dropout probability

    # Instantiate the model
    model = TabularModel(emb_szs, n_cont, out_sz, layers, p=p)
    
    # Load the saved state dictionary
    # map_location='cpu' ensures it loads correctly even if trained on GPU
    model.load_state_dict(torch.load('TaxiFareRegrModel.pt', map_location=torch.device('cpu')))
    
    # Set the model to evaluation mode (disables dropout, batch norm updates)
    model.eval() 
    return model

model = load_trained_model()

# --- 4. Streamlit Application Layout and Logic ---
st.title('🚖 Taxi Fare Predictor')
st.markdown("""
This app predicts the fare amount for a taxi ride based on various trip details.
Please enter the information below:
""")

# Input fields for trip details
st.header('Trip Details')

# ADD THE CAUTIONARY TEXT HERE
st.warning("""
**Use Caution!** This model was trained on New York City taxi data.
For a fair prediction, please use latitude and longitude values that are close to one another.

* **1° latitude ≈ 111km (69mi)**
* **1° longitude ≈ 85km (53mi)**

The model works best for short to medium-length trips, with a typical difference of only about 0.02 degrees for both latitude and longitude.
""")

col1, col2 = st.columns(2)

with col1:
    pickup_lat = st.number_input('Pickup Latitude', value=40.7128, format="%.6f", help="e.g., 40.7128 (for NYC)")
    pickup_long = st.number_input('Pickup Longitude', value=-74.0060, format="%.6f", help="e.g., -74.0060 (for NYC)")
    dropoff_lat = st.number_input('Dropoff Latitude', value=40.7580, format="%.6f", help="e.g., 40.7580 (for NYC)")
    dropoff_long = st.number_input('Dropoff Longitude', value=-73.9855, format="%.6f", help="e.g., -73.9855 (for NYC)")

with col2:
    passenger_count = st.slider('Number of Passengers', min_value=1, max_value=6, value=1)
    
    # Date and Time inputs
    pickup_date = st.date_input('Pickup Date', value=datetime.now().date())
    pickup_time = st.time_input('Pickup Time', value=datetime.now().time())

# Button to trigger prediction
if st.button('Calculate Estimated Fare'):
    # --- 5. Preprocess User Input for Model ---
    
    # Combine date and time into a single datetime object
    edt_datetime_str = f"{pickup_date} {pickup_time}"
    
    # Create a DataFrame for consistent processing with haversine_distance
    dfx_dict = {
        'pickup_latitude': pickup_lat,
        'pickup_longitude': pickup_long,
        'dropoff_latitude': dropoff_lat,
        'dropoff_longitude': dropoff_long,
        'passenger_count': passenger_count,
        'EDTdate': edt_datetime_str
    }
    dfx = pd.DataFrame(dfx_dict, index=[0])

    # Calculate distance
    dfx['dist_km'] = haversine_distance(dfx, 'pickup_latitude', 'pickup_longitude',
                                        'dropoff_latitude', 'dropoff_longitude')
    
    # Convert 'EDTdate' to datetime object
    dfx['EDTdate'] = pd.to_datetime(dfx['EDTdate'])

    # Extract categorical features
    dfx['Hour'] = dfx['EDTdate'].dt.hour
    dfx['AMorPM'] = np.where(dfx['Hour'] < 12, 0, 1) # 0 for AM, 1 for PM
    
    # Map Weekday to numerical values (0-6)
    weekday_mapping = {
        'Fri': 0, 'Mon': 1, 'Sat': 2, 'Sun': 3, 'Thu': 4, 'Tue': 5, 'Wed': 6
    }
    dfx['Weekday'] = dfx['EDTdate'].dt.strftime("%a").replace(weekday_mapping).astype('int64')

    # Define categorical and continuous columns for model input
    cat_cols = ['Hour', 'AMorPM', 'Weekday']
    cont_cols = ['pickup_latitude', 'pickup_longitude', 'dropoff_latitude',
                 'dropoff_longitude', 'passenger_count', 'dist_km']

    # Prepare tensors for the model
    # Categorical features need to be LongTensor
    xcats = np.stack([dfx[col].values for col in cat_cols], axis=1)
    xcats = torch.tensor(xcats, dtype=torch.int64)
    
    # Continuous features need to be FloatTensor
    xconts = np.stack([dfx[col].values for col in cont_cols], axis=1)
    xconts = torch.tensor(xconts, dtype=torch.float)

    # --- 6. Make Prediction with the Model ---
    with torch.no_grad(): # Disable gradient calculation for inference
        prediction_tensor = model(xcats, xconts)
        predicted_fare = prediction_tensor.item() # Get the scalar value from the tensor

    # --- 7. Display the Result ---
    st.success(f'The predicted taxi fare amount is: **${predicted_fare:.2f}**')

st.markdown("---")
st.markdown("Developed with ❤️ using Streamlit and PyTorch.")